import 'package:flutter_app/Model/BaseCate.dart';
import 'package:json_annotation/json_annotation.dart';

part 'CateItem.g.dart';

@JsonSerializable()
class CateItem {
  CateItem(this.title, this.image,this.bannerList,this.child);

  String title;
  String image;
  @JsonKey(name: 'banner_list')
  List<BaseCate> bannerList;
  List<BaseCate> child;

  factory CateItem.fromJson(Map<String, dynamic> json) => _$CateItemFromJson(json);

  Map<String, dynamic> toJson() => _$CateItemToJson(this);
}