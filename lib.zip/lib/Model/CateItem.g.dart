// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'CateItem.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CateItem _$CateItemFromJson(Map<String, dynamic> json) {
  return CateItem(
    json['title'] as String,
    json['image'] as String,
    (json['child'] as List)
        ?.map((e) =>
            e == null ? null : BaseCate.fromJson(e as Map<String, dynamic>))
        ?.toList(),
    (json['child'] as List)
        ?.map((e) =>
            e == null ? null : BaseCate.fromJson(e as Map<String, dynamic>))
        ?.toList(),
  );
}

Map<String, dynamic> _$CateItemToJson(CateItem instance) => <String, dynamic>{
      'title': instance.title,
      'image': instance.image,
      'banner_list': instance.bannerList,
      'child': instance.child
    };
