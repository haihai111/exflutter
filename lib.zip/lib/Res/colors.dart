import 'package:flutter/material.dart';

final Color red = Color(0xffe5101d);
final Color white = Color(0xffffffff);
final Color black = Color(0xff000000);
final Color gray = Color(0xffa6a6a6);
final Color background = Color(0xffe9e9e9);
